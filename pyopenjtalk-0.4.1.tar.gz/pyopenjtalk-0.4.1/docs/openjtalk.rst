pyopenjtalk.openjtalk
=====================

The core cython module for OpenJTalk's text processing frontend.

.. automodule:: pyopenjtalk.openjtalk

OpenJTalk
---------

.. autoclass:: OpenJTalk
    :members:
