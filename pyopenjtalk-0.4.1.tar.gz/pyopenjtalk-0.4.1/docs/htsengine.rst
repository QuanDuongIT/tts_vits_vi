pyopenjtalk.htsengine
=====================

The cython module for HTSEngine.

.. automodule:: pyopenjtalk.htsengine

HTSEngine
---------

.. autoclass:: HTSEngine
    :members:
