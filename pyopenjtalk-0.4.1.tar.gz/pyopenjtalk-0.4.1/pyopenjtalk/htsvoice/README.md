# LICENSE for test data

- [LICENSE_mei](LICENSE_mei_normal.htsvoice): LICENSE for mei_normal.voice
